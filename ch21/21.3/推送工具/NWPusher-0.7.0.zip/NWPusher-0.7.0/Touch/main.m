//
//  main.m
//  Pusher
//
//  Copyright (c) 2013 noodlewerk. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NWAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([NWAppDelegate class]));
    }
}
