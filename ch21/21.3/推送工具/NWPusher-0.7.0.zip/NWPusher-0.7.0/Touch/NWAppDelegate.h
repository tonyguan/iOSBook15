//
//  NWAppDelegate.h
//  Pusher
//
//  Copyright (c) 2013 noodlewerk. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface NWPusherViewController : UIViewController

@end


@interface NWAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
